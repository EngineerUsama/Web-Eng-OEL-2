
var o = 0;
if(JSON.parse(sessionStorage.getItem("products"))){
    console.log("Already defined")
}
else{
    console.log("defining now")
    sessionStorage.setItem("products", JSON.stringify([
        {
            picture: "https://upload.wikimedia.org/wikipedia/commons/d/de/Nokota_Horses_cropped.jpg",
            name: "Horse",
            price: "$534",
            isrented: false,
            pno: 0
        },
    
        {
            picture: "https://www.pngitem.com/pimgs/m/331-3314068_knife-with-blood-png-transparent-png.png",
            name: "Knife",
            price: "$423",
            isrented: false,
            pno: 1
        },
    
        {
            picture: "https://w1.pngwing.com/pngs/894/818/png-transparent-background-yellow-frame-bicycle-bicycle-suspension-mountain-bike-hercules-cycle-and-motor-company-bicycle-frames-car-roadeo-thumbnail.png",
            name: "Bicycle",
            price: "$45560",
            isrented: false,
            pno: 2
        },
    
        {
            picture: "https://thumbs.dreamstime.com/b/close-up-mm-pistol-ammunition-hand-gun-dark-background-military-bunch-bullets-metal-table-162799115.jpg",
            name: "9mm Pistol",
            price: "$0",
            isrented: false,
            pno: 3
        },
    
        {
            picture: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbQbtW89HiCT1plXAsy-ArEZEZ6mM9LUZboQ&usqp=CAU",
            name: "AK47",
            price: "-$400",
            isrented: false,
            pno: 4
        },
        {
            picture: "https://cdn11.bigcommerce.com/s-i32t4keptf/images/stencil/1280x1280/products/3324/4472/Sling3__48403.1643067018.jpg?c=1",
            name: "RPG 47",
            price: "-$9000",
            isrented: false,
            pno: 5
    
        }
    ]));
}
let product =  JSON.parse(sessionStorage.getItem("products"))

function Item(Name) {
    if (Name == "all") {
        product.map(AllProd);
    }
    else if (Name == "rent") {
        product.map(RProd);
    }
}

function AllProd(i) {
    var x = document.getElementById("c").innerHTML +=
        `<div class="card">
        <img src=${i.picture} alt="Product" style="width:auto;height:200px;" />
        <h3>${i.name}</h3>
        <p class="price">${i.price}</p>
        <button type="button" class="btn btn-info" onclick=addToRent(${i.pno})>Add To Rent</button>
        </div>`;
    return x;
}

function RProd(i) {
    if (i.isrented == true) {
        var x = document.getElementById("c").innerHTML +=
            `<div class="card">
        <img src=${i.picture} alt="Product" style="width:auto;height:200px;" />
        <h3>${i.name}</h3>
        <p class="price">${i.price}</p>
        </div>`;
    }

    return x;
}


function addToRent(j) {
    product[j].isrented = true;
    sessionStorage.setItem("products",JSON.stringify(product))
}
